package SJF;

import java.awt.List;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Vector;

public abstract class Strategy {
	
	
	protected Vector<Job> Jobs;
	protected ArrayList<Job> Queue;
	
	
	public Strategy(Vector<Job> jobs){
		super();
		Jobs =jobs;
	}
	
	public abstract void run();

}
