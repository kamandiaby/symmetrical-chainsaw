package SJF;

import java.util.LinkedList;
import java.util.Vector;


public class SJF extends Strategy {

	
	

	public SJF(Vector<Job> jobs) {
		super(jobs);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}
	
	public void run(Vector<Job> jobList){
		float avgTurnArroundTime = 0;
		float avgWaitimeTime = 0;
		int n;
		n = jobList.size();
		Vector<Integer> p = new Vector<Integer>();
		Vector<Integer> at = new Vector<Integer>();
		Vector<Integer> bt = new Vector<Integer>();
		Vector<Integer> bt2 = new Vector<Integer>();
		Vector<Integer> wt = new Vector<Integer>();
		Vector<Integer> tat = new Vector<Integer>();
		double tempWT =0;
		int count = 0;
		
		for(Job job: jobList){
			
			p.set(count, count);
			at.set(count, job.getArrivalTime());
			bt.set(count, job.getCPUTime());
			bt2.set(count, bt.get(count));
			count++;
		}
		
		int tbt = 0;
		
		for(int i=0; i < n; i++){
			tbt =  tbt + bt.get(i);
		}
		
		Vector<Integer> time = new Vector<Integer>();
		int m = 0;
		int l = 0;
		
		System.out.println("============================================ ");
        System.out.println("Process ID | Turnaround time | Waiting time ");
        System.out.println("============================================ ");
        int counter =1;
        for(int i= 0; i <tbt; i++){
        	int q = Min(bt,at,tbt,i,n);
        	
        	if(q!=l){
        		time.setElementAt(i, m+1);
        		wt.set(q, i+ bt.get(q));
        		counter++;
        		tempWT = wt.get(q);
        	}
        	avgWaitimeTime +=wt.get(q);
        	avgTurnArroundTime +=tat.get(q);
        	bt.set(q, bt.get(q)-1);
        	l = q;
        	System.out.println(p.get(q)+1 + "\t|" +tat.get(q)+ "\t|\t" + wt.get(q));
        	System.out.println("----------------------------------------");
        	time.set(m, tbt);
        	System.out.println();
        	System.out.println("0\t");
        	
        	
        }
        
        for(int i=0; i<= m; i++){
    		System.out.println(time.get(i) + "\t");
    	}
        System.out.println("\n-----------------------------------------------------------------------------");
        System.out.println("Avg WaitingTime||TurnAroundTime::"+tempWT/counter+"|"+avgTurnArroundTime/counter);
        System.out.println("-------------------------------------------------------------------------------");
		
	}
	
	public int Min(Vector<Integer>b, Vector<Integer> a, int tbt, int r, int n){
		int j = 0;
        int min = tbt;
        for (int i = n - 1; i > 0; i--) {
            if (b.get(i) < min && b.get(i) > 0 && r <= a.get(i)) {
                min = b.get(i);
                j = i;
            }
        }
		
		return j;
		
	}

	
	

}
