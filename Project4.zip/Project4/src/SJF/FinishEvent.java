package SJF;

public interface FinishEvent {
	
	public void onFinish(Job j);

}
