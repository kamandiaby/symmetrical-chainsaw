package CMP426;

public interface JobFinishEvent {
	
	public void onFinish(Job j);

}
