package CMP426;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;

import SJF.SJF;

public class TextCase_FIFO {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		Scanner sc1 = new Scanner(System.in);
		Scanner sc2 = new Scanner(System.in);
		String filename;
		String allocationStrategy;
		int quantum = 10;

		filename = "texting.txt";
		allocationStrategy = "FIFO";

		if (args.length == 3) {
			quantum = new Integer(args[2]);

		}

		BufferedReader br = null;

		try {
			String sCurrentLine;
			br = new BufferedReader(new FileReader(filename));
			ArrayList<Job> JobList = new ArrayList<Job>();

			while ((sCurrentLine = br.readLine()) != null) {
				String a[] = sCurrentLine.split(" ,");
				int processId = new Integer(a[0]);
				int arrivalTime = new Integer(a[1]);
				int cpuTime = new Integer(a[2]);
				Job job = new Job(processId, arrivalTime, cpuTime);
				JobList.add(job);
			}

			if ("FIFO".equalsIgnoreCase(allocationStrategy)) {
				FIFO fifo = new FIFO(JobList);
				fifo.run();
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)
					br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		JobFinishEvent callback = new JobFinishEvent() {

			@Override
			public void onFinish(Job j) {
				// TODO Auto-generated method stub

			}

		};
		
		ArrayList jobs = new ArrayList();
		jobs.add(new Job(6,7,2,callback));
		jobs.add(new Job(2,1,3,callback));
		FIFO fifo = new FIFO(jobs);
		fifo.run();

	}

}
