package CMP426;


import java.awt.List;
import java.util.ArrayList;
import java.util.LinkedList;

public abstract class strategy {
	
	protected ArrayList<Job> Jobs;
	protected ArrayList<Job> Queue;
	
	public strategy(ArrayList<Job> jobs){
		super();
		Jobs = jobs;
	}
	public abstract void run();

}
