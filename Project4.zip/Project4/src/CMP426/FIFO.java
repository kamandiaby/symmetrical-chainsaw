package CMP426;

import java.awt.List;
import java.util.ArrayList;
import java.util.LinkedList;

public class FIFO extends strategy {
	
	int temp;
	int arrivalTime;
	int waitingTime;
	double avgWaitTime;
	double avgTurnAroundTime;
	
	public FIFO(ArrayList<Job> jobs){
		
		super(jobs);
		
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}
	public void run(ArrayList<Job> jobList){
		
		int count = 0;
		System.out.println("============================================ ");
        System.out.println("Process ID | Turnaround time | Waiting time ");
        System.out.println("============================================ ");
        
        for(Job job:jobList){
        	
        	if(count == 0){
        		job.processArrivalTime = job.getArrivalTime();
        		job.ProcessCompletionTime = job.getArrivalTime() + job.getCpuTime();
        	}
        	
        	else{
        		job.processArrivalTime = temp - job.getArrivalTime();
        		job.ProcessCompletionTime = temp + job.getCpuTime();
        	}
        	temp = job.ProcessCompletionTime;
        	job.turnAroundTime= temp  - job.getArrivalTime();
        	job.waitingTime = job.turnAroundTime - job.getCPUTime();
        	count++;
        	
        	avgWaitTime = avgWaitTime + job.waitingTime; 
        	avgTurnAroundTime = avgTurnAroundTime + job.turnAroundTime;
        	System.out.println(" "+ job.getProcessId()+ "|" + " "+ job.turnAroundTime + " | " + job.waitingTime+ " ");
        }
        
        System.out.println("--------------------------------------------");
        System.out.println("Avg waiting time:"+avgWaitTime/jobList.size());
        System.out.println("---------------------------------------------");
        System.out.println("Avg turn around time:"+avgTurnAroundTime/jobList.size());
        System.out.println("---------------------------------------------");
		
		
	}
		

}
